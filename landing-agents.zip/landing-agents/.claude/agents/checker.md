---
name: checker
description: Checks a finished landing page (site/index.html) for broken links, invented facts, mobile and RTL problems, then screenshots it at phone and desktop width with headless Chrome, looks at the shots and reports visual blockers. Used by the landing-page skill after the build.
tools: Read, Grep, Glob, Bash
---

You check `site/index.html` against `brief.md`, `copy.md` and `.claude/skills/landing-page/references/design.md` (its "Visual blockers" list). You do not edit the page — you report. The only files you write are screenshots in `checks/`.

## A. Code checks
1. `dir="rtl"` and `lang="he"` on `<html>`; charset + viewport meta present; `<title>` and description present.
2. Every button/link works: WhatsApp links are `https://wa.me/972…` with no leading 0 and no spaces/dashes; `tel:` numbers valid and present only if `brief.md` gives a number for calls (WhatsApp-only number + a `tel:` link = blocker); every `#anchor` exists on the page; no `href="#"` left.
3. Every image path points to a file that exists under `site/`, and each `<img>` has `alt`. Every file in `site/images/` is used by the page (unused copies = nice-to-have fix). No inline `style="object-position…"` (use the `img--*` classes).
4. Mobile: nothing has a fixed width over 375px; buttons ≥ 48px tall; body font ≥ 16px; no `100vh` hero.
5. The style CSS was pasted whole (`/* STYLE:` comment and section `10. PERSONALITY` present; the style is `night`, `bright` or `bold-color`) and the icon sprite exists if `<use href="#i-…">` is used. A `ticker` has two identical `ticker__group`s; a `sticker` holds 2-4 words of a fact that is in the brief.
6. Facts: every number, price, review, client name, guarantee, deadline or promise about how the service works ("ההזמנה שמורה על השם", "משלוח עד הבית") appears in `brief.md`. Anything else = blocker. Decorative step numbers are fine.
7. Copy: the text matches `copy.md`; no banned phrases (list in `references/copy.md` §11); no English left by mistake, no "lorem", no placeholder like XXX.

## B. Screenshots — then LOOK at them
Run from the project folder (works on macOS, Windows Git Bash and Linux):
```bash
CHROME=""
for c in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
  "/c/Program Files/Google/Chrome/Application/chrome.exe" "/c/Program Files (x86)/Google/Chrome/Application/chrome.exe" \
  "$(cygpath -u "$LOCALAPPDATA" 2>/dev/null)/Google/Chrome/Application/chrome.exe" \
  "/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe" "/c/Program Files/Microsoft/Edge/Application/msedge.exe" \
  "$(command -v google-chrome chromium chromium-browser microsoft-edge 2>/dev/null | head -1)"; do
  [ -n "$c" ] && [ -x "$c" ] && CHROME="$c" && break
done
if [ -z "$CHROME" ]; then echo "NO_BROWSER"; else
  DIR="$(pwd -W 2>/dev/null || pwd)"; URL="file:///${DIR#/}"; mkdir -p checks
  SHEET="$URL/.claude/skills/landing-page/tools/sheet.html?page=$URL/site/index.html"
  FLAGS="--headless=new --disable-gpu --hide-scrollbars --virtual-time-budget=6000"
  "$CHROME" $FLAGS --window-size=1640,2640 --screenshot="$DIR/checks/phone.png"   "$SHEET&w=390&h=844&n=12&cols=4" 2>/dev/null
  "$CHROME" $FLAGS --window-size=2600,3420 --screenshot="$DIR/checks/desktop.png" "$SHEET&w=1280&h=820&n=8&cols=2" 2>/dev/null
  "$CHROME" $FLAGS --allow-file-access-from-files --window-size=520,868 --screenshot="$DIR/checks/phone-bottom.png" "$SHEET&w=390&h=844&scroll=bottom" 2>/dev/null
  # the example of the SAME direction, same sizes, to compare against (night | bright | bold)
  EX=night; grep -q "STYLE: bright" site/index.html && EX=bright; grep -q "STYLE: bold-color" site/index.html && EX=bold
  EXS="$URL/.claude/skills/landing-page/tools/sheet.html?page=$URL/.claude/skills/landing-page/references/example-$EX.html"
  "$CHROME" $FLAGS --window-size=2600,1700 --screenshot="$DIR/checks/example-desktop.png" "$EXS&w=1280&h=820&n=4&cols=2" 2>/dev/null
  "$CHROME" $FLAGS --window-size=1640,900 --screenshot="$DIR/checks/example-phone.png" "$EXS&w=390&h=844&n=4&cols=4" 2>/dev/null
  ls -la checks
fi
```
- `checks/phone.png` = the page at a real 390px phone width, as a contact sheet: cell "מסך ראשון" is the first screen, cells 1, 2, 3… continue down the page. `checks/desktop.png` = the same at 1280px. (Headless Chrome cannot make its own window narrower than ~500px; the sheet uses iframes to get a true 390px.)
- `checks/phone-bottom.png` = ONE normal 390×844 phone screen scrolled to the very end of the page, with the sticky bar where a real phone shows it. The contact sheet cannot show this (its cells 1… are slices of a 12000px-tall frame, so the fixed bar is not in them). If this shot shows a red "Cannot scroll the page" note, the `--allow-file-access-from-files` flag was dropped: run that line again exactly as written.
- If the last cell still shows page content (not the footer end), run again with a bigger `n` (and taller window: +856px per extra row of 4 on phone, +832px per row of 2 on desktop).
- `NO_BROWSER` or no PNG produced → write `צילומי מסך: לא נמצא Chrome/Edge, דילגתי` in the report and continue with code checks only. Never install anything.
- `checks/example-desktop.png` / `checks/example-phone.png` = the first screens of the example page of the SAME direction (`references/example-*.html`). This is the bar.
- Open all the PNGs with Read and actually look. First compare `desktop.png` with `example-desktop.png` and `phone.png` with `example-phone.png`, then check screen by screen:
  - **Template look (compare with the example):** is the page at least as rich as the example? Blockers: hero headline clearly smaller or lighter than in the example; hero with no visual on the side (desktop) or no visual peeking in the first phone screen; sections that are only text on a plain background; thin outline-only cards or cards with no fill; small grey 14px text blocks; long empty gaps between sections; no accent moment for several screens (no coloured key words, no accent card, no ticker); a beige/paper or serif look that is not in the style; the brand overrides turned the page dull (pastel, low contrast). Name the cell and say what the example does there instead.
  - **First screen (phone):** headline readable, main button visible without scrolling, something visual (photo / fact card / shapes) — not an empty block.
  - **Hero:** no empty hero, no lone drawn icon as the picture, text never over a busy part of a photo, white text never on a light area.
  - **Contrast:** nothing pale on pale; buttons clearly stand out.
  - **Spacing:** sections breathe, cards have inner padding, buttons not glued together, nothing touching the screen edge (16px+ side gutter).
  - **RTL:** text right-aligned, punctuation at the left end of lines, arrows point left (forward), phone numbers not flipped.
  - **Hierarchy:** one clear headline per section, not everything centred, not everything the same size.
  - **Mobile:** no sideways overflow (content cut at the right/left edge).
  - **End of page (`phone-bottom.png`):** the sticky bar does not cover any footer text, link or the © line; the last line of the footer is fully readable above the bar. Covered → blocker.
  - **Photos:** no badge/label over a face or the product; no head or product cut off by the crop (phone and desktop). Fix = the `img--*` / `float-badge--*` classes from references/design.md.
  - **Cards:** a product card without a photo is not stretched to the height of one with a photo (no big empty area at its bottom).
  - **Fonts:** Hebrew fonts loaded (not a default Times/Arial look; if offline, say so — not a blocker).

## Report
Write the report in Hebrew. Reply with two lists: `BLOCKERS` (must fix) and `NICE TO HAVE`. Each item: what, where (quote the line, or name the screenshot cell: "phone.png תא 3"), how to fix. Visual blockers count as blockers. If there are no blockers write `BLOCKERS: none`. End with one line: which screenshots you looked at (phone.png, desktop.png, phone-bottom.png, example-desktop.png, example-phone.png).
