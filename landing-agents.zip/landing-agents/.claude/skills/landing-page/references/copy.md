# Copy method: Hebrew landing pages that sell

Read this before writing a single line. Facts come ONLY from `brief.md`. The method shapes the words; it never adds facts.

## 1. One reader, one action
- Write to ONE person: the customer described in the brief, on their phone, a bit distracted. Not "לקוחות", not "כולם". Address them as "אתם".
- The page has ONE action (the one in the brief). Every section ends by pointing at it. No second offer, no newsletter, no "עקבו אחרינו" next to the main button.
- Before writing, finish this sentence for yourself: "אחרי 5 שניות בדף, הגולש מבין ש___ ושכדי לקבל את זה הוא ___." If you can't, the hero is not ready.

## 2. Hero formulas (pick one, then cut words)
The headline sells the RESULT for the reader, not the business. Max ~8 words.
| Formula | Pattern | Example |
|---|---|---|
| Result + no-pain | [what they get] + [the effort/objection removed] | "חלה חמה לשישי, בלי לעמוד בתור" |
| Result + time | [result] + [in how long] (only if the brief gives the time) | "אתר שמביא פניות, מוכן תוך 7 ימים" |
| Who + result | [for whom] + [result] | "לאמהות אחרי לידה: לחזור לכושר מהבית" |
| The pain, flipped | [the moment they hate] → [the fix] | "נמאס לחפש חניה? המספרה עם חניה צמודה" |

- **Sub (one sentence):** HOW it happens + the strongest objection-killer from the brief. "מזמינים בוואטסאפ עד חמישי, ובשישי החלה מחכה בשקית עם השם."
- **Button:** verb + outcome (see §8). **Under the button:** one line of micro-copy that removes the last fear (§9).
- **Trust line (optional):** 2-4 short TRUE facts from the brief ("שאור טבעי", "איסוף 7:00-13:00"). No facts → no trust line.
- Put the key words of the headline inside `<em>` in the copy (`headline: חלה חמה לשישי, <em>בלי לעמוד בתור</em>`): the design highlights them.

## 3. Problem → agitate → solution
- **Problem:** 2-3 lines the reader recognises from THEIR week, concrete and visual. "ב-8:00 התור כבר יוצא מהדלת." Not "אנחנו יודעים שקשה למצוא מאפייה טובה".
- **Agitate:** what it costs them (time, money, the kid's face, the lost Friday). One line is enough. Never scare, never shame.
- **Solution:** how THIS business removes it, step by step, in their language. If there is a process, write it as 3 steps (verb first: "שולחים הודעה", "מקבלים אישור", "אוספים בשישי").

## 4. Benefits, not features: the "כלומר" test
Every feature from the brief goes through: **feature → "כלומר" → what changes for the reader.**
- "בצק שתופח 18 שעות" → כלומר → "קרום פריך, פנים רך, וחלה שנשארת טעימה גם בשבת בבוקר."
- "ליווי בוואטסאפ" → כלומר → "שאלה ב-11 בלילה? יש למי לכתוב."
Write the benefit card as: title = the feature in 2-4 words, line = the "כלומר" part. If you can't finish the "כלומר" with something the reader feels, drop the feature.

## 5. Specific beats general
- Numbers, days, hours, names of places, steps: specific words are believed. "תשובה תוך שעה" > "שירות מהיר". But ONLY if the brief says it.
- Missing a number? Use a concrete PICTURE built only from facts in the brief instead of inventing one (brief says "order on WhatsApp, pick up Friday" → "שולחים הודעה ביום חמישי, ובשישי רק נכנסים ולוקחים"). Never add a service promise the brief does not state.

## 6. Objections → FAQ
The FAQ is where the sale is closed. 3-5 questions a hesitant buyer really asks, in their words:
price ("כמה זה עולה?"), time ("תוך כמה זמן?"), fit ("זה מתאים גם ל…?"), process ("איך זה עובד?"), risk ("ומה אם…?").
- **An answer may only restate facts from `brief.md` or send the reader to the action.** It is the place where copywriters slip in promises ("מתאים לכל רמה", "נתאים לכם תוכנית", "אפשר לבטל מתי שרוצים", "עונים מהר"): if the brief does not say it, the answer does not say it.
- Answer in 1-2 short sentences, start with the answer ("עד חמישי ב-14:00."), then the reason (the reason too must come from the brief).
- A fact missing from the brief → the answer sends them to the action: "המחיר תלוי בכמות. כתבו לנו בוואטסאפ ותקבלו מחיר תוך שעה." (only promise "תוך שעה" if the brief says so; otherwise just "כתבו לנו").
- An honest "לא" builds trust: "כרגע אין משלוחים, רק איסוף."

## 7. Risk reversal: only if true
Guarantee, free first meeting, "משלמים רק באיסוף", cancel anytime: these are the strongest lines on the page and they MUST be in the brief. Not in the brief → don't write one. Never "שביעות רצון מובטחת".

## 8. CTA wording
- **Verb (plural imperative) + what they get:** "הזמינו לשישי", "קבעו שיחת היכרות", "שלחו לי את המחיר", "שריינו מקום".
- Matches the action: WhatsApp button says what happens in WhatsApp ("שלחו הודעה", "הזמינו בוואטסאפ").
- 2-4 words. Never "לחצו כאן", "שלח", "המשך", "צור קשר" alone.
- The same main button text everywhere (hero, sticky bar, final). The sticky bar and the top bar use a 2-3 word short form (`## sticky`, `## topbar` in copy.md).
- "התקשרו" / a call button only if the brief gives a number for calls. WhatsApp-only number → every CTA is WhatsApp.

## 9. Micro-copy under buttons
One short line that answers "what happens if I click?": "עונים תוך שעה · משלמים רק באיסוף", "בלי התחייבות", "לוקח 30 שניות". Only true things from the brief.

## 10. Scannable
- Short paragraphs: 1-3 lines on a phone. One idea per sentence.
- Section titles say the point ("מזמינים באמצע השבוע. אוספים בדקה."), not the category ("השירות שלנו", "אודות").
- A reader who reads only titles + buttons should still get the whole offer.

## 11. Tone
Spoken Hebrew, the way the owner would say it to a customer at the counter. Short, warm, direct. Plural "אתם". No exclamation-mark storms (max one on the page).

**Banned** (rewrite if you see them): מהווה · חדשני / חדשנית · פתרון מקיף / פתרון מושלם · ברוכים הבאים · אנחנו מאמינים · אנו · הינו / הינה · מגוון רחב · ברמה הגבוהה ביותר · איכות ללא פשרות · שירות מקצועי ואדיב · חוויה בלתי נשכחת · הצוות המקצועי שלנו · לא תאמינו · "כאן" כשם של לינק · אודות.

## 12. Never invent
No prices, numbers, years of experience, client counts, reviews, star ratings, awards, client names, "הכי", "מספר 1", deadlines or scarcity ("נשארו 3 מקומות") unless they are in `brief.md`. A fact marked `(הנחה)` stays vague. When in doubt, leave it out; the design looks fine without it.

## Before / after
**Before (template):**
> ברוכים הבאים למאפיית הדר! אנו מאמינים באיכות ללא פשרות ומהווים פתרון מקיף לכל צורכי המאפה שלכם. צרו קשר.

**After (method):**
> **חלה חמה לשישי, בלי לעמוד בתור**
> מזמינים בוואטסאפ עד חמישי ב-14:00. בשישי בבוקר החלה כבר מחכה לכם על המדף, בשקית עם השם.
> [הזמינו לשישי בוואטסאפ]
> עונים תוך שעה · משלמים רק באיסוף

What changed: the result in the headline, the objection (queue) killed, the how in one sentence, a verb+outcome button, the last fear removed under it. (Every fact here is from that brief.)
