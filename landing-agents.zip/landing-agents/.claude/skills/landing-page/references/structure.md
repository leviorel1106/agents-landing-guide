# Page structure: blueprints by business type

Pick ONE blueprint from the brief, write its name at the top of `copy.md` (`blueprint: service`), and keep its order. Skip a section when the brief has nothing true for it (no reviews → no proof section); never fill a section with invented content. Every section has a job; if it doesn't do the job, cut it.

Section ids (used for anchors and by the checker): `top` (hero), `problem`, `solution`, `benefits`, `about`, `menu` (products/offer), `proof`, `faq`, `info`, `order` (final CTA).

With photos (the user's or Kolbo's), add the photo moments to the blueprint: a `statement` line right after the hero, an `about` section with a big photo (the owner only from their real photo; otherwise the place/the work), a photo `strip` (3-4 photos) or a `photo-break` between two text sections. A page with photos has the hero + at least two of these.

## A. service: local business / service provider
(hairdresser, clinic, plumber, photographer, trainer, lawyer, cleaner)
| # | Section | Must achieve |
|---|---|---|
| 1 | hero | result + objection killer + button; trust line with area/hours if true |
| 2 | problem | "that's me": 3 moments of the pain |
| 3 | solution + steps | how it works in 3 steps, from first message to result |
| 4 | benefits (3) | the 3 strongest "כלומר" benefits |
| 5 | gallery / strip / about | photos of the place and the work (real, or Kolbo scenes without faces); the people behind it only from real photos |
| 6 | proof | real reviews from the brief |
| 7 | offer / price | if a price or package is in the brief |
| 8 | faq | price, area, timing, "what if" |
| 9 | info | hours, address/area, phone |
| 10 | final | one line + the same button |

## B. product: shop / food / product
(bakery, caterer, cosmetics, handmade, a single product)
| # | Section | Must achieve |
|---|---|---|
| 1 | hero | the product's moment of joy + how to get it; photo if there is one |
| 2 | menu / products | what can be ordered NOW, with prices from the brief |
| 3 | problem | why the usual way is annoying (queue, quality, delivery) |
| 4 | solution + steps | order → confirm → get it |
| 5 | benefits (3) | what makes it taste/feel/last better, through "כלומר" |
| 6 | proof | real reviews, real photos of customers' orders |
| 7 | faq | allergens, delivery/pickup, payment, deadlines |
| 8 | info | pickup/delivery area, hours, address |
| 9 | final | the order button again |
(Products can also come after the problem; keep them in the first half of the page, as in `example-bold.html`.)

## C. course: course / expert / coaching
(online course, workshop, consultant, coach, mentor)
| # | Section | Must achieve |
|---|---|---|
| 1 | hero | the transformation (from → to) + format + button |
| 2 | problem | where the reader is stuck today, in their words |
| 3 | solution | the method in 3 steps or 3 modules |
| 4 | what you get | checklist: lessons, files, support (only what exists) |
| 5 | who it's for / not for | two short lists; "not for" builds trust |
| 6 | about | the expert: one photo, 2-3 true lines of WHY they can help |
| 7 | proof | real results/reviews |
| 8 | offer | price, what's included, guarantee only if true |
| 9 | faq | time per week, level, access, refunds |
| 10 | final | the same button |

## D. event: event / workshop date / launch
| # | Section | Must achieve |
|---|---|---|
| 1 | hero | what happens + date + place + button ("שריינו מקום") |
| 2 | what you'll get / feel | 3 benefits |
| 3 | schedule | the agenda as steps (time → what) |
| 4 | who's speaking / hosting | real people only |
| 5 | info | date, hour, address, parking, price |
| 6 | faq | who it suits, what to bring, cancellation |
| 7 | final | the button + the date again |
Countdown or "few seats left" only if the brief gives a real limit.

## Above the fold (first screen on a phone, 390×844)
- [ ] Who it is for / what they get is clear from the headline alone
- [ ] The main button is visible without scrolling
- [ ] One line of micro-copy under the button
- [ ] Something visual: a real photo, OR a fact card (the 3 key facts), OR big type with shapes. Never an empty coloured block, never a lone drawn icon as the "image"
- [ ] The brand name or logo is in the top bar, small
- [ ] No menu with links that lead away; at most one small button in the top bar

## Mobile-first rules
- Design for a 390px phone first; desktop is the same page with more room.
- **Thumb zone:** the main action lives at the bottom of the screen: a sticky bar with the main button (+ an optional phone icon button). It hides while the hero button is on screen.
- Body text 16px or more (the styles use 17px), line height ~1.7, lines of ~60-75 characters on desktop.
- Every tap target at least 48×48px (buttons are 52-58px tall), with at least 8px between targets.
- No horizontal scroll: no fixed widths, images `max-width:100%`, long words/links allowed to wrap.
- Buttons are full width on phones; side by side on desktop.
- Phone numbers are `tel:` links (only a number the brief gives for calls; a WhatsApp-only number gets WhatsApp links only), addresses are map links, WhatsApp is `https://wa.me/972…?text=` with a ready first message.
- Hebrew + numbers: wrap phone numbers in `<span dir="ltr">` so they don't flip.
- Fast: no video backgrounds, images under ~300KB each, at most 2 font families.
