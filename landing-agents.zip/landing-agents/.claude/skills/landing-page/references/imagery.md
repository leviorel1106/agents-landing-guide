# Photos and the hero video with Kolbo: shot list, look, prompts, honesty, ready files

A landing page with real-looking photos of the business feels like a premium site; the same page with shapes only feels like a template. What lifts it furthest is the **hero video**: a short, slow moving video behind the headline, made from the hero photo. This file is read by the lead, the `designer` (writes the shot list) and the `imagery` agent (generates with Kolbo).

Kolbo = an image + video studio: dozens of image and video models in one place, one account, with an MCP for Claude Code and a built-in agent in the browser called **Kobi** ("קובי, הסוכן של קולבו"). Always present it as photos + video, never "just images". Video is optional and costs more credits than a photo. Sign-up: https://app.kolbo.ai?via=orellevi (codes for the first purchase, monthly plans only: `ORELLEVI50` = 50% off the first month, `ORELLEVI30` = 30% off for 3 months; never other numbers or price claims). Setup: `npx -y @kolbo/mcp install`, then restart Claude Code; the first generation opens a browser login (click Allow), or use an API key from app.kolbo.ai/developer.

## 0. Ready files from Kobi (the easy path, no connection)
Users who don't want to connect anything open Kolbo in the browser, ask Kobi in plain words (e.g. "תמונה לראש הדף של סטודיו פילאטיס בתל אביב, אור בוקר רך, ווידאו קצר שלה שזזה לאט"), download the files and drop them into `images/`. They are ready assets, used without generating and without credits:
- **Video file** (`.mp4`, `.mov`, `.webm`) in `images/` = the hero video. More than one → the one whose look matches the hero photo, else the first by name; mention the others to the user. The lead prepares it (SKILL.md step 2.5 item 0):
  - poster = the photo it was made from when it is in `images/` (same picture as the first frame); otherwise its first frame: `ffmpeg -i images/<file> -frames:v 1 -q:v 3 images/gen/hero.jpg`.
  - the file: `ffmpeg -i images/<file> -an -vf scale='min(1280,iw)':-2 -c:v libx264 -crf 28 -pix_fmt yuv420p -movflags +faststart images/gen/hero.mp4` (still > 4 MB → `-crf 32`; longer than 8 s → add `-t 6`). An `.mp4` that is already H.264, silent and ≤ 4 MB may be copied as is.
  - no ffmpeg → install it (Mac: `brew install ffmpeg`; Windows: `winget install --id Gyan.FFmpeg -e`, then restart Claude Code); still no ffmpeg → use the file only if it is an `.mp4` ≤ 4 MB, else skip the video and say why in one line.
  - `images.md`: `video: images/gen/hero.mp4 | hero__video | poster: images/gen/hero.jpg (or images/<photo>) | <seconds> s · <MB> MB · ready (Kobi)` and the poster as the hero photo line.
- **Wide, sharp, text-free photo** of the place or product = a ready hero photo (`hero__bg` for `hero--full`, the `wash` for arch/split, or the arch frame by its aspect). Other good photos = ready section photos (about, strip, split). The designer places them; the shot list only fills what they don't cover.
- Ready generated photos follow every rule below (no letters, no warped hands, no generated face presented as the owner/staff/customer). A bad one → leave it out and tell the user in one line.

## 1. The shot list (designer writes it in design.md)
3-6 photos, never more. Each line:
`id | purpose | section | aspect | subject (one line) | prompt (English)`
- `hero` — the hero photo. `hero--arch` / `hero--split` → 3:4; `hero--full` → 16:9 with calm space on the RIGHT side for the text.
- `wash` (with `hero--arch` or `hero--split`: plan it, it is what makes the hero feel like a real place) — the place, wide (16:9), calm, no people: it is shown faded behind the hero.
- `about` — 3:4. With an owner photo in `images/`: the owner in the business setting, made FROM that photo. Without: the place or the work (hands, tools, a detail), never a stranger's face.
- `strip-1…3` / `split` / `break` — 2-3 more photos for the strip, the solution split or a photo break: details, the space at another hour, the product in use, the materials. 4:5 or 3:4 for the strip, 4:3 for a split, 16:9 for a break.
- Order the list by importance: if the budget is cut, the last lines go first.

## 2. One look for the whole page (the LOOK line)
Write ONE look line in the shot list and append it to every prompt, so all photos look like one shoot (same light, palette, lens, grain). Match it to the design direction:
| Direction | LOOK line (adapt the palette words to the brand) |
|---|---|
| `luxe` | `soft natural window light from the side, warm cream, sand and white palette with small brass/gold details, calm minimal interior, shot on a full-frame camera with a 50mm lens at f/2, shallow depth of field, fine film grain, editorial lifestyle photography, true-to-life colours` |
| `bright` | `bright clean daylight, white and light grey surfaces, one touch of the brand colour in the scene, shot on a 35mm lens at f/2.8, crisp, natural colours, modern professional photography` |
| `night` | `low-key evening light, warm practical lamps and soft rim light, deep shadows, rich dark tones, shot on a 35mm lens at f/1.8, cinematic, subtle film grain` |
| `bold-color` | `bright cheerful daylight, saturated colours with the brand colour present in props or background, slightly top-down, shot on a 35mm lens, punchy and fresh, appetising` |

## 3. Prompt formula (realism)
`[subject and action] , [place, with 2-3 concrete real details] , [composition: framing, where the empty space is] , [LOOK line] , [realism tail]`
Realism tail (always): `photorealistic, real textures, natural skin with pores and small imperfections, relaxed natural hands with five fingers, no text, no letters, no logos, no watermark, not CGI, not plastic, not over-retouched`.
- Concrete beats pretty: "a rolled grey mat, a wooden reformer with cream leather straps, late-morning sun on a pale oak floor" > "a beautiful studio".
- Israeli context when it is real for the business: Israeli apartment light, Tel Aviv street outside the window, local products; no flags or slogans.
- People without an owner photo: only bodies from behind, hands, feet, silhouettes, out-of-focus figures — never a sharp face that the page could present as the owner, staff or a customer.
- **Specialised equipment hides its details.** Image models get the mechanics of real machines wrong (a pilates reformer's springs and carriage, a dental chair, a barber chair, gym machines, musical instruments, medical or salon devices): a full, sharp view of the machine looks fake to anyone who knows it. Generate such equipment ONLY in angles where its details are hidden or soft: close-ups of hands/feet on a strap, handle or texture; shallow depth of field with the machine out of focus behind; partial views (one corner, one edge, a wheel, a cushion). Prefer people's hands, materials, light and the space over the full machine. Never a whole machine as the hero, never two machines side by side in focus.
- No words in the image. Signs, packaging text, screens → leave them blank; the page writes all words in HTML.
- Composition for the layout: arch → subject centred, head room on top (the arch cuts the top corners); full → subject on the LEFT third, calm space on the right for the Hebrew text; about → subject in the upper half.

## 4. Models, size, cost (always ask first)
Call `list_models` (model ids change) and `check_credits`. Default: a fast photoreal model at 1K for everything (on Kolbo: a Nano Banana model; GPT Image when the photo must hold fine detail). 2K only for the hero when the user wants it.
Before generating, show the user ONE Hebrew line with the plan and the estimated credits, e.g.:
`אצור 5 תמונות לדף (Nano Banana, 1K): בערך 50 קרדיטים מתוך 2,300 שיש לכם. להמשיך?` — and wait for a yes.
Generate the photos in parallel calls (one call per photo, all in one message). Use 1 variation each; a second try only for a photo that failed the check (section 5), and say it costs again.

## 5. Check every photo before it goes on the page (look at it)
Reject and regenerate (once) if: letters or logos appeared; a specialised machine (reformer, dental/barber chair, gym machine, instrument) is shown whole and sharp, or its parts look wrong (fix: closer, partial, shallow focus); hands/fingers/limbs are warped; a face is sharp and recognisable when it should not be; skin looks plastic; the photo's light or palette breaks the set; the subject sits where the layout puts text or a chip. Two fails → drop that photo and use the CSS layout for that spot.

## 6. Files
- Save to `images/gen/<id>.jpg` (convert to JPG, max 1600px on the long side, ~200-350KB). The tool returns an image URL or the image itself: download/save it, never hotlink.
- Write `images.md`: one line per file — `images/gen/hero.jpg | hero (arch) | img--center | alt: "…Hebrew…"` — the builder reads it. Alt = what is in the photo, in plain Hebrew (not the business slogan).
- Kolbo not connected, no credits, or the user said no → write `images.md` with `none` and one line why (but keep any ready files from §0 in it); the page is built with the CSS heroes (`hero--type`) and still must reach the bar of its example.

## 7. Hero video with Kolbo (image-to-video, only after its own yes)
The single thing that most turns a regular page into a premium one: the headline sits on a calm, moving picture. Offered once, after the photos are approved, only when there is no ready video from §0, and only for `hero--full` / `hero--arch` / `hero--split` (never `hero--type`). It is optional and costs more credits: the page is complete without it.
- **Source photo** = the photo that fills the hero background: `hero--full` → `images/gen/hero.jpg`; `hero--arch` / `hero--split` → the `wash` photo (shown faded behind the hero). The video starts from that exact photo, so the page looks the same before it plays.
- **Model and cost.** `list_models` with type video; pick a cheap, fast image-to-video model that takes a start image (no audio needed). A video costs far more credits than a photo: show the user ONE Hebrew line with the real estimate (model, length, credits, what they have) and wait for a yes. One video, one try; a retry only with a new yes.
- **Settings.** 4-6 seconds, the photo's aspect ratio (16:9), the lowest resolution that looks sharp at full width (720p/1080p), no sound.
- **Prompt (English)** — calm and loopable: `slow subtle motion only: [1-2 natural movements of THIS place: steam rising from a cup, leaves moving in the window light, a curtain breathing, light shifting slowly on the floor], locked-off camera or a very slow push-in, no cuts, no new objects, no people appearing, no text, the last frame close to the first frame for a seamless loop, same light and colours as the image`.
- **Check it** (open it / look at 3 frames): no warping, no text, no faces appearing, nothing jumps at the loop point, the calm text area stays calm. Fails → no video (or one retry with the user's yes).
- **File.** Save as `images/gen/hero.mp4`, H.264, no audio, **≤ 4 MB**. Larger and ffmpeg exists (`ffmpeg -version`) → `ffmpeg -i in.mp4 -an -vf scale=1280:-2 -c:v libx264 -crf 28 -movflags +faststart images/gen/hero.mp4` (still > 4 MB → `-crf 32`). No ffmpeg and > 4 MB → skip the video.
- Add to `images.md`: `video: images/gen/hero.mp4 | hero__video | poster: images/gen/hero.jpg | <seconds> s · <MB> MB · credits: <n>` (poster = the source photo).
