# Design system: 3 directions, one set of components

Every page is built from:
1. ONE style file from `styles/`, pasted **verbatim** into `<style>` (then, if needed, a short `:root{}` override block AFTER it for brand colours),
2. the icon sprite `icons.svg`, pasted once right after `<body>`,
3. the component markup below (same class names in all three styles).

The quality bar is the example page of the chosen direction — open it before building:
`example-night.html` (barbershop), `example-bright.html` (physio clinic), `example-bold.html` (pizzeria). Each is built ONLY from these pieces, without photos. Your page must look at least that designed.

## Pick a direction
| Direction | Feels | Fits | Fonts |
|---|---|---|---|
| `night` (**default**) | near-black, giant heavy type, gradient key words, soft glows, glass cards, cream pill buttons | most businesses: services, beauty, barbers, fitness, creators, courses, events, tech, premium products, restaurants/bars with a night vibe | Rubik 400-900 |
| `bright` | white, giant black type, ONE vivid accent used boldly (accent blocks, numbers, a full accent closing block), bento cards, strong soft shadows | clinics, therapists, consultants, lawyers, accountants, real estate, studios, B2B, apps, professionals | Heebo 400-900 |
| `bold-color` | the brand colour as whole-section backgrounds alternating with white, chunky type, sticker and label shapes, ink pill buttons with a 3D edge | food, bakeries, pizza, ice cream, cafés, kids, toys, pets, local shops, markets, events, family workshops | Secular One + Rubik |
Not sure → `night`. Professional service where calm trust matters more than mood → `bright`. Food, kids, local or a party → `bold-color`. The site the client likes (brief) beats the table: match its light/dark and its mood.
Never fall back to a beige/paper look, thin serif headlines or small grey text: those were removed on purpose.

## Adapt to the brand (don't redesign)
- Each style file starts with a `BRAND` comment that lists the ONLY tokens to override for a brand colour. Put them in a `:root{}` block after the style file. Everything else (glows, tints, card edges, the ticker, the closing band, `--focus`) is derived from them with `color-mix()` inside the style file, so it recolours by itself. Never add a hex/rgba accent colour anywhere else.
  - `night`: `--g1 --g2` (gradient stops: the brand colour + a second tone that goes with it), `--accent` (= `--g1`), `--accent-strong` (a LIGHT tint of the brand, ≥ 4.5:1 on #0c0d10), `--accent-fill` (a gradient dark enough for white text). The cream buttons stay cream.
  - `bright`: `--accent` (strong enough for white text, ≥ 4.5:1), `--accent-strong` (accent for text on white), `--accent-hover`. A light brand colour (yellow, mint) → use a darker shade of it as `--accent`.
  - `bold-color`: `--accent` (the section colour — saturated, never pastel), `--accent-ink` (text on it: near-black `#140F0C` for light/medium colours, `#FFFFFF` for dark ones, ≥ 4.5:1), `--accent-2` (sticker/label colour, default yellow), `--accent-strong` (brand colour dark enough for text on white).
- Check contrast and write it in `design.md`: text ≥ 4.5:1 on its background, big headings ≥ 3:1.
- Logo in `images/` → `<a class="brand" href="#top"><img src="images/logo.png" alt="[שם העסק]"></a>`. No logo → `<span class="brand__mark">[first letter]</span>[שם העסק]`.
- Never more than the style's fonts. Don't change the type scale or spacing tokens; that is where the quality lives.

## Pick the hero (by the photos in `images/`)
| Photos | Hero | Rule |
|---|---|---|
| A strong wide photo with calm space for text (place, people, product in context) | `hero--full` | Text sits on the scrim side (right). Busy photo with no calm area → use `hero--split` instead |
| A good photo that is not wide / has no calm area (portrait, product, the owner) | `hero--split` | Photo next to the text; optional `float-badge` with ONE true fact |
| No photos, or only weak/low-res ones | `hero--type` | Giant headline + the style's shapes + a `factcard` with the 3 key facts of the offer (menu + prices, date + place + price, "how it works" in 3 lines) + optional `sticker`. Never an empty hero, never a lone drawn icon as the picture |

## Page rhythm
- Alternate backgrounds: `section` → `section section--alt` → `section` …; the closing band is `final`, then `footer`. In `bold-color` every `section--alt` is a full brand-colour section, so alternating is what makes the page: never two `alt` in a row, never a page without them.
- Right under the hero, add the `ticker` band when the copy has 3+ short true facts (the hero `trust` lines): it gives the page energy at no cost.
- One centred section head per 2-3 sections at most (`sec-head--center`); the rest are right-aligned (RTL start). Centred everything = template look.
- Each section: eyebrow (2-3 words) → h2 (the point, ≤ 8 words, with the key words in `<em>` — the style colours them: gradient / accent / label) → optional lead → the component.
- Put `<em>` on 1-3 key words of most h2s (not all of them), never on a whole title.
- Accent colour is for buttons, eyebrows, icons and key words only. Never for big areas of body text.

## Components (copy the markup; keep the class names)
Icons: `<svg class="ico" aria-hidden="true"><use href="#i-NAME"/></svg>`. Names: check, x, clock, pin, phone, chat (WhatsApp), star, shield, truck, heart, spark, calendar, users, gift, leaf, bag, play, arrow.

**Top bar**
```html
<header class="topbar"><div class="wrap topbar__in">
  <a class="brand" href="#top"><span class="brand__mark" aria-hidden="true">ק</span>שם העסק</a>
  <a class="btn btn--wa btn--sm" href="WA_LINK"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg>TOPBAR BUTTON</a>
</div></header>
```
TOPBAR BUTTON = `## topbar` → `button` in `copy.md` (2-3 words; the long hero button does not fit there).
**Hero: common inner part** (`.hero__text`)
```html
<div class="hero__text">
  <p class="eyebrow">WHO / WHERE</p>
  <h1 class="hero__title">HEADLINE <em>KEY WORDS</em></h1>
  <p class="hero__sub">SUB</p>
  <div class="ctas">
    <a class="btn btn--wa btn--lg" href="WA_LINK"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg>BUTTON</a>
    <a class="btn btn--ghost btn--lg" href="#menu">SECOND (optional, an anchor)</a>
  </div>
  <p class="btn-note"><svg class="ico" aria-hidden="true"><use href="#i-clock"/></svg>MICRO-COPY</p>
  <ul class="trust"><li><svg class="ico" aria-hidden="true"><use href="#i-leaf"/></svg>TRUE FACT</li></ul>
</div>
```
Main button: `btn--wa` when the action is WhatsApp, else `btn--primary` (`tel:` / form / shop link).

- `hero--type`: `<section class="hero hero--type" id="top"><div class="hero__shapes" aria-hidden="true"><span></span><span></span><span></span></div><div class="wrap hero__in">[hero__text]<div class="hero__visual"><span class="sticker">2-4 WORDS</span><div class="factcard">…</div></div></div></section>`
  sticker (optional, both `hero--type` and `hero--split`): a round tilted badge on the corner of the visual with ONE true fact from the copy (`hero` → `sticker`), 2-4 short words ("בלי לחכות בחוץ", "תור תוך 48 שעות"). No true short fact → leave it out. Put it as the FIRST child of `.hero__visual`. It sits on the top corner at the END side (left in RTL): on a photo, use it only when that corner has no face or product (else use the `float-badge` instead).
  factcard: `<p class="factcard__label">[icon]LABEL</p><p class="factcard__title">TITLE</p><ul class="factcard__rows"><li><span class="k">NAME<small>DETAIL</small></span><span class="v">VALUE</span></li>…</ul><p class="factcard__foot">[icon]KEY CONDITION</p>`
- `hero--split` (focus class and badge corner: see "Photos: focus and badges"): `<section class="hero hero--split" id="top"><div class="hero__shapes" aria-hidden="true"><span></span><span></span><span></span></div><div class="wrap hero__in">[hero__text]<div class="hero__visual"><img class="hero__img img--top" src="images/x.jpg" alt="…"><div class="float-badge">[icon]ONE TRUE FACT</div></div></div></section>`
- `hero--full`: `<section class="hero hero--full" id="top"><img class="hero__bg" src="images/x.jpg" alt="…"><div class="wrap hero__in">[hero__text]</div></section>`

On phones the hero is already ordered for the first screen: headline → sub → main button (the second button becomes a text link) → note → the visual (fact card / photo) → trust chips. Don't fight it with extra CSS.

**Ticker** (optional, right after the hero section, before the first `section`): the same 3-5 short true facts twice, in two identical groups (that is what makes the loop seamless):
```html
<div class="ticker" aria-hidden="true"><div class="ticker__track">
  <div class="ticker__group"><span>FACT</span><span>FACT</span><span>FACT</span><span>FACT</span></div>
  <div class="ticker__group"><span>FACT</span><span>FACT</span><span>FACT</span><span>FACT</span></div>
</div></div>
```
Facts: 1-4 words each, from the hero `trust` lines or `## ticker` in copy.md. Never invented.

**Section shell**
```html
<section class="section section--alt" id="ID"><div class="wrap">
  <div class="sec-head"><p class="eyebrow">EYEBROW</p><h2>TITLE</h2><p class="lead">LEAD</p></div>
  …component…
</div></section>
```
**Problem**: `<ul class="pains"><li><svg class="ico" aria-hidden="true"><use href="#i-users"/></svg><p>PAIN LINE</p></li>…×3</ul>`
**Text + visual** (solution, about, who-it's-for): `<div class="wrap split"><div class="split__text">eyebrow, h2, lead, <ul class="checks"><li>[i-check]LINE</li></ul></div><div class="split__visual">IMG (class split__img) or <ol class="steps">…</ol></div></div>`. Add `split--flip` to put the visual first on desktop.
**Steps**: `<ol class="steps"><li><div><h3>STEP</h3><p>LINE</p></div></li>…</ol>`; `steps steps--row` = 3 across on desktop.
**Benefits** (bento: the FIRST card is drawn big — put the strongest benefit first): `<div class="benefits"><article class="benefit"><span class="benefit__icon">[icon]</span><h3>TITLE</h3><p>כלומר: …</p></article>…×3</div>`
**Products / menu** (a card without a photo shows the price big on top, so text-only menus still look designed): `<div class="products"><article class="product">[<img class="product__img" src alt> only if real]<div class="product__body"><span class="tag">TAG</span><div class="product__top"><h3>NAME</h3><span class="price">28 ₪</span></div><p>LINE</p></div></article>…</div>`
**One offer / price**: `<div class="offer"><span class="tag">TAG</span><h3>NAME</h3><p class="offer__price">390 ₪ <small>WHEN</small></p><ul class="checks">…</ul><a class="btn btn--primary btn--block btn--lg">BUTTON</a><p class="btn-note">MICRO</p></div>`
(Cards with and without a photo can sit in one grid: each card keeps its own height, a text-only card does not stretch to the photo card's height.)
**Gallery** (real photos only): `<div class="gallery"><img src alt>…</div>` (first photo is shown big).
**Testimonials** (real only, from the brief): `<div class="quotes"><figure class="quote"><blockquote>QUOTE</blockquote><figcaption><span class="quote__avatar" aria-hidden="true">מ</span><span><span class="quote__name">NAME</span><span class="quote__meta">DETAIL</span></span></figcaption></figure>…</div>`. Optional `<div class="stars">` with 5 `i-star` icons ONLY if the brief has a real rating.
**FAQ**: `<div class="faq"><details open><summary>QUESTION</summary><div class="faq__a"><p>ANSWER</p></div></details>…</div>` (only the first one `open`).
**Info**: `<div class="info"><div class="info__item"><span class="info__icon">[icon]</span><div><span class="info__label">LABEL</span><span class="info__value">VALUE</span></div></div>…</div>`
**Form** (only with a real endpoint the user gave): `<form class="form" action="URL" method="post"><div class="field"><label for="n">שם</label><input id="n" name="name" autocomplete="name" required></div>…<button class="btn btn--primary btn--lg">BUTTON</button></form>`
**Final**: `<section class="final" id="order"><div class="wrap wrap--narrow"><p class="eyebrow">…</p><h2>CLOSING LINE</h2><p class="lead">…</p><div class="ctas">[main button]</div><p class="btn-note">…</p></div></section>`
**Footer**: `<footer class="footer"><div class="wrap footer__in"><div>[brand]<p class="footer__about">ONE LINE</p></div><ul class="footer__links"><li><a href="WA">[i-chat]וואטסאפ</a></li><li><a href="tel:+972…">[i-phone]<span dir="ltr">05X-XXX-XXXX</span></a></li></ul><p class="footer__small">© NAME</p></div></footer>`
**Sticky mobile bar** + script (hides while the hero button is visible):
```html
<div class="sticky-cta" id="sticky">
  <a class="btn btn--wa" href="WA_LINK"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg>SHORT BUTTON</a>
  <a class="btn btn--ghost btn--icon" href="tel:+972…" aria-label="התקשרו"><svg class="ico" aria-hidden="true"><use href="#i-phone"/></svg></a>
</div>
<script>(function(){var b=document.getElementById('sticky'),h=document.querySelector('.hero .ctas');if(!b||!h||!('IntersectionObserver' in window))return;new IntersectionObserver(function(e){b.classList.toggle('is-hidden',e[0].isIntersecting)}).observe(h);})();</script>
```
(No phone for calls in the brief — e.g. a WhatsApp-only number → drop the icon button, and the footer has no `tel:` line. `tel:` only when the brief gives a number for calls.)

## Photos: focus and badges
All photos are cropped with `object-fit:cover`. Choose which part stays in frame with ONE class on the `<img>` — never an inline `style="object-position:…"`:
| Class | Keeps in frame | Typical use |
|---|---|---|
| `img--top` | top edge | portraits, faces, a person standing |
| `img--center` | middle (default) | products, dishes, places |
| `img--bottom` | bottom edge | food on a table seen from above, shoes, floors |
| `img--left` / `img--right` | left / right edge | subject standing at one side of a wide photo |
Phones crop differently (the hero photo becomes 4:3, cards get narrower). Add a phone-only class when the subject would be cut there: `img--m-top`, `img--m-center`, `img--m-bottom`, `img--m-left`, `img--m-right` (apply up to 640px wide). Example: `<img class="hero__img img--center img--m-top" …>`.

**Floating labels/badges (`float-badge`) must never cover the face or the product**, above all in portrait photos. Rule: put the badge in the corner OPPOSITE the subject, and on phones under the image if the photo has no empty corner:
- default = bottom corner on the start side (right in RTL); `float-badge--top` moves it to the top; `float-badge--end` moves it to the other side;
- `float-badge--m-below` = on phones (≤ 640px) the badge drops out of the photo and sits under it.
Example: face in the lower right of the photo → `<div class="float-badge float-badge--top float-badge--end float-badge--m-below">`. Not sure → use `float-badge--m-below`, and check the phone screenshot.

## Visual blockers (the checker looks for these)
- Looks like a template next to the matching `example-*.html`: small headline, thin outline cards, lots of empty space, no accent moments, everything grey. The page must have the same weight as the example.
- Empty or near-empty hero (a coloured block with a headline and nothing else).
- A single drawn icon standing in for a photo.
- Text over a busy photo without the scrim, or white text on a light area.
- A badge or label covering a face or the product; a photo cropped so the head or the product is cut off (fix with the `img--*` classes).
- Pale on pale (grey text on beige), accent text that fails 4.5:1.
- Cramped: sections touching, cards without padding, buttons stuck together.
- Broken RTL: arrows pointing the wrong way, punctuation at the wrong end, phone numbers flipped.
- Everything centred, everything the same size: no hierarchy.
- More than 2 fonts, more than one accent colour fighting.
