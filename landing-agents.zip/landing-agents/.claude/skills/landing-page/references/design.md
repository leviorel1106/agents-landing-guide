# Design system: 4 directions, one set of components

Every page is built from:
1. ONE style file from `styles/`, pasted **verbatim** into `<style>` (then, if needed, a short `:root{}` override block AFTER it for brand colours),
2. the icon sprite `icons.svg`, pasted once right after `<body>`,
3. the component markup below (same class names in all four styles),
4. the photos: the user's own in `images/` and the ones the `imagery` agent generated with Kolbo in `images/gen/` (listed in `images.md`).

The quality bar is the example page of the chosen direction — open it before building:
`example-night.html` (barbershop), `example-bright.html` (physio clinic), `example-bold.html` (pizzeria) — built without photos, so they show the floor; `example-luxe.html` (boutique pilates studio) — built with Kolbo-generated photos: this is the level a page WITH photos must reach (arch hero, photo strip, about with a big photo, dark FAQ).
Photos are what separates a premium page from a template. When `images.md` exists, every page uses a photo-led hero and at least two more photo moments (about / strip / photo break / split image).

## Pick a direction
| Direction | Feels | Fits | Fonts |
|---|---|---|---|
| `night` (**default**) | near-black, giant heavy type, gradient key words, soft glows, glass cards, cream pill buttons | most businesses: services, beauty, barbers, fitness, creators, courses, events, tech, premium products, restaurants/bars with a night vibe | Rubik 400-900 |
| `bright` | white, giant black type, ONE vivid accent used boldly (accent blocks, numbers, a full accent closing block), bento cards, strong soft shadows | clinics, therapists, consultants, lawyers, accountants, real estate, studios, B2B, apps, professionals | Heebo 400-900 |
| `bold-color` | the brand colour as whole-section backgrounds alternating with white, chunky type, sticker and label shapes, ink pill buttons with a 3D edge | food, bakeries, pizza, ice cream, cafés, kids, toys, pets, local shops, markets, events, family workshops | Secular One + Rubik |
| `luxe` | warm cream alternating with near-black sections, ONE gold accent (thin gold lines, gold key words, gold buttons with dark text), arch-framed hero photo, big portrait in "about", dark FAQ. Calm and expensive | coaches, therapists, mentors, clinics, beauty and aesthetics, boutique studios (pilates, yoga), consultants, designers, premium personal services | Rubik + Assistant |
Not sure → `night`. Personal or boutique service that sells trust and taste (a coach, a clinic, a studio, beauty) → `luxe`, above all when there are photos (the user's or Kolbo's). Professional service where calm, plain trust matters more than mood → `bright`. Food, kids, local or a party → `bold-color`. The site the client likes (brief) beats the table: match its light/dark and its mood.
Never fall back to a beige/paper look, thin serif headlines or small grey text: those were removed on purpose. (`luxe` is cream, but with black sections, heavy sans headlines and gold lines — a flat beige page with grey text is still a blocker.)

## Adapt to the brand (don't redesign)
- Each style file starts with a `BRAND` comment that lists the ONLY tokens to override for a brand colour. Put them in a `:root{}` block after the style file. Everything else (glows, tints, card edges, the ticker, the closing band, `--focus`) is derived from them with `color-mix()` inside the style file, so it recolours by itself. Never add a hex/rgba accent colour anywhere else.
  - `night`: `--g1 --g2` (gradient stops: the brand colour + a second tone that goes with it), `--accent` (= `--g1`), `--accent-strong` (a LIGHT tint of the brand, ≥ 4.5:1 on #0c0d10), `--accent-fill` (a gradient dark enough for white text). The cream buttons stay cream.
  - `bright`: `--accent` (strong enough for white text, ≥ 4.5:1), `--accent-strong` (accent for text on white), `--accent-hover`. A light brand colour (yellow, mint) → use a darker shade of it as `--accent`.
  - `bold-color`: `--accent` (the section colour — saturated, never pastel), `--accent-ink` (text on it: near-black `#140F0C` for light/medium colours, `#FFFFFF` for dark ones, ≥ 4.5:1), `--accent-2` (sticker/label colour, default yellow), `--accent-strong` (brand colour dark enough for text on white).
  - `luxe`: `--accent` (the metal/brand colour: gold by default; sand, rose-gold, olive, deep green work), `--accent-ink` (text on accent buttons, ≥ 4.5:1), `--accent-strong` (accent dark enough for text on cream #FBF9F4, ≥ 4.5:1), `--accent-on-ink` (light tint for words on the black sections, ≥ 4.5:1 on #111). No brand colour → keep the gold.
- Check contrast and write it in `design.md`: text ≥ 4.5:1 on its background, big headings ≥ 3:1.
- Logo in `images/` → `<a class="brand" href="#top"><img src="images/logo.png" alt="[שם העסק]"></a>`. No logo → `<span class="brand__mark">[first letter]</span>[שם העסק]`.
- Never more than the style's fonts. Don't change the type scale or spacing tokens; that is where the quality lives.

## Pick the hero (by the photos in `images/` and `images/gen/`)
| Photos | Hero | Rule |
|---|---|---|
| A tall (3:4) photo of the owner, or of the place/product with one clear subject | `hero--arch` | The photo in an arch frame + `arch__chip` with ONE true fact (a star rating ONLY if the brief gives a real one). Optional `hero__wash` (a wide photo of the place, faded behind the hero) and `arch__moon` (a second small round photo). The default photo hero of `luxe`; fine in every style |
| A strong wide photo with calm space for text (place, people, product in context) | `hero--full` | Text sits on the scrim side (right). Busy photo with no calm area → use `hero--split` or `hero--arch` instead |
| A good photo that is not wide / has no calm area (portrait, product, the owner) | `hero--split` | Photo next to the text; optional `float-badge` with ONE true fact |
| No photos, or only weak/low-res ones (and Kolbo not connected) | `hero--type` | Giant headline + the style's shapes + a `factcard` with the 3 key facts of the offer (menu + prices, date + place + price, "how it works" in 3 lines) + optional `sticker`. Never an empty hero, never a lone drawn icon as the picture |

## Photos that may be used (the honesty rule)
- `images/` = the user's real photos. `images/gen/` = photos generated with Kolbo (see `images.md` for each file's place and alt).
- A generated photo shows a scene, a space, a product, hands, a detail, a mood. It NEVER shows a face that the page presents as the owner, a staff member or a customer, unless it was made FROM the owner's real photo (then it is the owner, in a new setting). No owner photo → no "about" portrait of a person: the about section shows the place or the work, and the text speaks as the business.
- Testimonials: only quotes from the brief, with a real photo only if the brief gives one (`img.quote__avatar`); otherwise the letter avatar. Never a generated face next to a quote.
- Never text inside a photo (no signs, labels or logos generated into it); all words are HTML.

## Page rhythm
- Alternate backgrounds: `section` → `section section--alt` → `section` …; the closing band is `final`, then `footer`. A third background, `section section--ink` (near-black), works in every style and every component inside it turns dark by itself: use it for 1-2 sections that should feel weighty (the problem, "about", the FAQ). In `luxe` the ink sections ARE the rhythm: cream → ink → cream/alt → ink (FAQ) → final (black), never two ink in a row, at least two on the page. In `bold-color` every `section--alt` is a full brand-colour section, so alternating is what makes the page: never two `alt` in a row, never a page without them.
- Right under the hero, add the `ticker` band when the copy has 3+ short true facts (the hero `trust` lines): it gives the page energy at no cost.
- One centred section head per 2-3 sections at most (`sec-head--center`); the rest are right-aligned (RTL start). Centred everything = template look.
- Each section: eyebrow (2-3 words) → h2 (the point, ≤ 8 words, with the key words in `<em>` — the style colours them: gradient / accent / label) → optional lead → the component.
- Put `<em>` on 1-3 key words of most h2s (not all of them), never on a whole title.
- Accent colour is for buttons, eyebrows, icons and key words only. Never for big areas of body text.

## Components (copy the markup; keep the class names)
Icons: `<svg class="ico" aria-hidden="true"><use href="#i-NAME"/></svg>`. Names: check, x, clock, pin, phone, chat (WhatsApp), star, shield, truck, heart, spark, calendar, users, gift, leaf, bag, play, arrow.

**Top bar**
```html
<header class="topbar"><div class="wrap topbar__in">
  <a class="brand" href="#top"><span class="brand__mark" aria-hidden="true">ק</span>שם העסק</a>
  <a class="btn btn--wa btn--sm" href="WA_LINK"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg>TOPBAR BUTTON</a>
</div></header>
```
TOPBAR BUTTON = `## topbar` → `button` in `copy.md` (2-3 words; the long hero button does not fit there).
**Hero: common inner part** (`.hero__text`) — the same inside every hero type
```html
<div class="hero__text">
  <p class="eyebrow">WHO / WHERE</p>
  <h1 class="hero__title">HEADLINE <em>KEY WORDS</em></h1>
  <p class="hero__sub">SUB</p>
  <div class="ctas">
    <a class="btn btn--wa btn--lg" href="WA_LINK"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg>BUTTON</a>
    <a class="btn btn--ghost btn--lg" href="#menu">SECOND (optional, an anchor)</a>
  </div>
  <p class="btn-note"><svg class="ico" aria-hidden="true"><use href="#i-clock"/></svg>MICRO-COPY</p>
  <ul class="trust"><li><svg class="ico" aria-hidden="true"><use href="#i-leaf"/></svg>TRUE FACT</li></ul>
</div>
```
Main button: `btn--wa` when the action is WhatsApp, else `btn--primary` (`tel:` / form / shop link).

- `hero--type`: `<section class="hero hero--type" id="top"><div class="hero__shapes" aria-hidden="true"><span></span><span></span><span></span></div><div class="wrap hero__in">[hero__text]<div class="hero__visual"><span class="sticker">2-4 WORDS</span><div class="factcard">…</div></div></div></section>`
  sticker (optional, both `hero--type` and `hero--split`): a round tilted badge on the corner of the visual with ONE true fact from the copy (`hero` → `sticker`), 2-4 short words ("בלי לחכות בחוץ", "תור תוך 48 שעות"). No true short fact → leave it out. Put it as the FIRST child of `.hero__visual`. It sits on the top corner at the END side (left in RTL): on a photo, use it only when that corner has no face or product (else use the `float-badge` instead).
  factcard: `<p class="factcard__label">[icon]LABEL</p><p class="factcard__title">TITLE</p><ul class="factcard__rows"><li><span class="k">NAME<small>DETAIL</small></span><span class="v">VALUE</span></li>…</ul><p class="factcard__foot">[icon]KEY CONDITION</p>`
- `hero--split` (focus class and badge corner: see "Photos: focus and badges"): `<section class="hero hero--split" id="top"><div class="hero__shapes" aria-hidden="true"><span></span><span></span><span></span></div><div class="wrap hero__in">[hero__text]<div class="hero__visual"><img class="hero__img img--top" src="images/x.jpg" alt="…"><div class="float-badge">[icon]ONE TRUE FACT</div></div></div></section>`
- `hero--full`: `<section class="hero hero--full" id="top"><img class="hero__bg" src="images/x.jpg" alt="…"><div class="wrap hero__in">[hero__text]</div></section>`
- `hero--arch` (photo in an arch, chip on its lower corner):
```html
<section class="hero hero--arch" id="top">
  <img class="hero__wash" src="images/gen/space-wide.jpg" alt="">            <!-- optional: a wide photo of the place, faded -->
  <div class="hero__shapes" aria-hidden="true"><span></span><span></span><span></span></div>
  <div class="wrap hero__in">
    [hero__text]
    <div class="hero__visual"><div class="arch">
      <div class="arch__frame"><img class="img--center" src="images/gen/hero.jpg" alt="…" width="900" height="1200"></div>
      <img class="arch__moon img--center" src="images/gen/detail.jpg" alt="…">   <!-- optional second photo, round -->
      <div class="arch__chip"><svg class="ico" aria-hidden="true"><use href="#i-users"/></svg>ONE TRUE FACT</div>
    </div></div>
  </div>
</section>
```
  Chip with a REAL rating from the brief: `<div class="arch__chip"><div class="stars">[5× i-star]</div><span><strong>4.9</strong> · בגוגל</span></div>`. A face in the lower part of the photo → `arch__chip--top`.

**Hero video** (optional, only when `images.md` has a `video:` line): a muted loop behind the hero text, under the same overlay. Put it right AFTER the background photo and keep the photo (poster, fallback, and what reduced-motion users see; the CSS hides the video for them):
```html
<!-- hero--full -->
<img class="hero__bg" src="images/gen/hero.jpg" alt="…">
<video class="hero__video" autoplay muted loop playsinline preload="auto" poster="images/gen/hero.jpg" aria-hidden="true"><source src="images/gen/hero.mp4" type="video/mp4"></video>
<!-- hero--arch / hero--split: the faded wash -->
<img class="hero__wash" src="images/gen/wash.jpg" alt="">
<video class="hero__video hero__video--wash" autoplay muted loop playsinline preload="auto" poster="images/gen/wash.jpg" aria-hidden="true"><source src="images/gen/hero.mp4" type="video/mp4"></video>
```
The poster is the photo the video was made from. No `controls`, no sound, mp4 ≤ 4 MB.

On phones the hero is already ordered for the first screen: headline → sub → main button (the second button becomes a text link) → note → the visual (fact card / photo) → trust chips. Don't fight it with extra CSS.

**Ticker** (optional, right after the hero section, before the first `section`): the same 3-5 short true facts twice, in two identical groups (that is what makes the loop seamless):
```html
<div class="ticker" aria-hidden="true"><div class="ticker__track">
  <div class="ticker__group"><span>FACT</span><span>FACT</span><span>FACT</span><span>FACT</span></div>
  <div class="ticker__group"><span>FACT</span><span>FACT</span><span>FACT</span><span>FACT</span></div>
</div></div>
```
Facts: 1-4 words each, from the hero `trust` lines or `## ticker` in copy.md. Never invented.

**Section shell**
```html
<section class="section section--alt" id="ID"><div class="wrap">
  <div class="sec-head"><p class="eyebrow">EYEBROW</p><h2>TITLE</h2><p class="lead">LEAD</p></div>
  …component…
</div></section>
```
**Problem**: `<ul class="pains"><li><svg class="ico" aria-hidden="true"><use href="#i-users"/></svg><p>PAIN LINE</p></li>…×3</ul>`
**Text + visual** (solution, about, who-it's-for): `<div class="wrap split"><div class="split__text">eyebrow, h2, lead, <ul class="checks"><li>[i-check]LINE</li></ul></div><div class="split__visual">IMG (class split__img) or <ol class="steps">…</ol></div></div>`. Add `split--flip` to put the visual first on desktop.
**Steps**: `<ol class="steps"><li><div><h3>STEP</h3><p>LINE</p></div></li>…</ol>`; `steps steps--row` = 3 across on desktop.
**Benefits** (bento: the FIRST card is drawn big — put the strongest benefit first): `<div class="benefits"><article class="benefit"><span class="benefit__icon">[icon]</span><h3>TITLE</h3><p>כלומר: …</p></article>…×3</div>`
**Products / menu** (a card without a photo shows the price big on top, so text-only menus still look designed): `<div class="products"><article class="product">[<img class="product__img" src alt> only if real]<div class="product__body"><span class="tag">TAG</span><div class="product__top"><h3>NAME</h3><span class="price">28 ₪</span></div><p>LINE</p></div></article>…</div>`
**One offer / price**: `<div class="offer"><span class="tag">TAG</span><h3>NAME</h3><p class="offer__price">390 ₪ <small>WHEN</small></p><ul class="checks">…</ul><a class="btn btn--primary btn--block btn--lg">BUTTON</a><p class="btn-note">MICRO</p></div>`
(Cards with and without a photo can sit in one grid: each card keeps its own height, a text-only card does not stretch to the photo card's height.)
**Gallery** (photos of the place/work, real or generated scenes): `<div class="gallery"><img src alt>…</div>` (first photo is shown big).
**Gallery strip** (3-4 photos in a row; swipe on phones; optional short caption per photo): `<div class="strip"><figure><img class="img--center" src alt><figcaption>CAPTION</figcaption></figure>…</div>` — put it in its own section with a sec-head, or under the solution steps.
**Statement** (one big centred sentence right after the hero/ticker, key words in `<em>`): `<section class="statement"><div class="wrap"><p>SENTENCE <em>KEY WORDS</em></p></div></section>`
**About with a big photo** (the owner from the user's real photo, or — without one — the place / the work): `<section class="section section--ink" id="about"><div class="wrap about"><figure class="about__photo"><img class="img--top" src alt></figure><div class="about__text"><p class="eyebrow">…</p><h2>…<em>…</em></h2><p>LINE</p><p>LINE</p><ul class="checks">…</ul></div></div></section>` (`about--flip` puts the photo on the other side on desktop).
**Icon cards** (3-6 short items: who it's for, what you get): `<div class="cards"><article class="card"><span class="card__icon">[icon]</span><h3>TITLE</h3><p>LINE</p></article>…</div>` (`cards cards--center` centres them).
**Photo break** (one wide photo between two sections, full bleed; optional caption with one true fact): `<figure class="photo-break"><img class="img--center" src alt><figcaption>FACT</figcaption></figure>`
**Split with a photo** (solution / place): in `.split__visual` put `<img class="split__img img--center" src alt>`.
**Testimonials** (real only, from the brief): `<div class="quotes"><figure class="quote"><blockquote>QUOTE</blockquote><figcaption><span class="quote__avatar" aria-hidden="true">מ</span><span><span class="quote__name">NAME</span><span class="quote__meta">DETAIL</span></span></figcaption></figure>…</div>`. Optional `<div class="stars">` with 5 `i-star` icons ONLY if the brief has a real rating.
**FAQ**: `<div class="faq"><details open><summary>QUESTION</summary><div class="faq__a"><p>ANSWER</p></div></details>…</div>` (only the first one `open`).
**Info**: `<div class="info"><div class="info__item"><span class="info__icon">[icon]</span><div><span class="info__label">LABEL</span><span class="info__value">VALUE</span></div></div>…</div>`
**Form** (only with a real endpoint the user gave): `<form class="form" action="URL" method="post"><div class="field"><label for="n">שם</label><input id="n" name="name" autocomplete="name" required></div>…<button class="btn btn--primary btn--lg">BUTTON</button></form>`
**Final**: `<section class="final" id="order"><div class="wrap wrap--narrow"><p class="eyebrow">…</p><h2>CLOSING LINE</h2><p class="lead">…</p><div class="ctas">[main button]</div><p class="btn-note">…</p></div></section>`
**Footer**: `<footer class="footer"><div class="wrap footer__in"><div>[brand]<p class="footer__about">ONE LINE</p></div><ul class="footer__links"><li><a href="WA">[i-chat]וואטסאפ</a></li><li><a href="tel:+972…">[i-phone]<span dir="ltr">05X-XXX-XXXX</span></a></li></ul><p class="footer__small">© NAME</p></div></footer>`
**Sticky mobile bar** + script (hides while the hero button is visible):
```html
<div class="sticky-cta" id="sticky">
  <a class="btn btn--wa" href="WA_LINK"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg>SHORT BUTTON</a>
  <a class="btn btn--ghost btn--icon" href="tel:+972…" aria-label="התקשרו"><svg class="ico" aria-hidden="true"><use href="#i-phone"/></svg></a>
</div>
<script>(function(){var b=document.getElementById('sticky'),h=document.querySelector('.hero .ctas');if(!b||!h||!('IntersectionObserver' in window))return;new IntersectionObserver(function(e){b.classList.toggle('is-hidden',e[0].isIntersecting)}).observe(h);})();</script>
```
**Floating WhatsApp** (desktop only, when the action is WhatsApp; put it right before the sticky bar): `<a class="wa-fab" href="WA_LINK" aria-label="וואטסאפ"><svg class="ico" aria-hidden="true"><use href="#i-chat"/></svg></a>`
(No phone for calls in the brief — e.g. a WhatsApp-only number → drop the icon button, and the footer has no `tel:` line. `tel:` only when the brief gives a number for calls.)

## Photos: focus and badges
All photos are cropped with `object-fit:cover`. Choose which part stays in frame with ONE class on the `<img>` — never an inline `style="object-position:…"`:
| Class | Keeps in frame | Typical use |
|---|---|---|
| `img--top` | top edge | portraits, faces, a person standing |
| `img--center` | middle (default) | products, dishes, places |
| `img--bottom` | bottom edge | food on a table seen from above, shoes, floors |
| `img--left` / `img--right` | left / right edge | subject standing at one side of a wide photo |
Phones crop differently (the hero photo becomes 4:3, cards get narrower). Add a phone-only class when the subject would be cut there: `img--m-top`, `img--m-center`, `img--m-bottom`, `img--m-left`, `img--m-right` (apply up to 640px wide). Example: `<img class="hero__img img--center img--m-top" …>`.

**Floating labels/badges (`float-badge`) must never cover the face or the product**, above all in portrait photos. Rule: put the badge in the corner OPPOSITE the subject, and on phones under the image if the photo has no empty corner:
- default = bottom corner on the start side (right in RTL); `float-badge--top` moves it to the top; `float-badge--end` moves it to the other side;
- `float-badge--m-below` = on phones (≤ 640px) the badge drops out of the photo and sits under it.
Example: face in the lower right of the photo → `<div class="float-badge float-badge--top float-badge--end float-badge--m-below">`. Not sure → use `float-badge--m-below`, and check the phone screenshot.

## Visual blockers (the checker looks for these)
- Looks like a template next to the matching `example-*.html`: small headline, thin outline cards, lots of empty space, no accent moments, everything grey. The page must have the same weight as the example.
- Empty or near-empty hero (a coloured block with a headline and nothing else).
- A single drawn icon standing in for a photo.
- Text over a busy photo without the scrim, or white text on a light area.
- A badge or label covering a face or the product; a photo cropped so the head or the product is cut off (fix with the `img--*` classes).
- Photos that don't belong together (different light, colour or lens from one image to the next), plastic "AI" skin, warped hands or bodies, letters or logos inside a photo, a generated face presented as the owner/staff/customer.
- `images.md` exists but the page has only one photo, or the hero is `hero--type`: the photos were wasted.
- Pale on pale (grey text on beige), accent text that fails 4.5:1.
- Cramped: sections touching, cards without padding, buttons stuck together.
- Broken RTL: arrows pointing the wrong way, punctuation at the wrong end, phone numbers flipped.
- Everything centred, everything the same size: no hierarchy.
- More than 2 fonts, more than one accent colour fighting.
