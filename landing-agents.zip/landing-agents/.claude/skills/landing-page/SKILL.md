---
name: landing-page
description: Build a one-file Hebrew (RTL) landing page with a team of parallel agents — copywriter, designer and checker — using a built-in copy method, section blueprints and three ready design directions, then hand back a page ready to upload. Use when the user asks for a landing page, "דף נחיתה", a sales page or a one-page site.
---

# Landing page with parallel agents

You are the lead. You do not write the page alone: you split the work between the agents in `.claude/agents/`, run them **at the same time**, then assemble and check.

The know-how lives in `references/` (paths below are relative to this skill folder, `.claude/skills/landing-page/`):
- `references/copy.md` — how the words sell (hero formulas, "כלומר" benefits, CTA rules, banned phrases)
- `references/structure.md` — section blueprints per business type, above-the-fold and mobile rules
- `references/design.md` — the 3 directions, hero choice, component markup, visual blockers
- `references/styles/*.css` — `night` (default), `bright`, `bold-color`: complete CSS, used verbatim
- `references/icons.svg` — inline icon sprite
- `references/example-night.html`, `example-bright.html`, `example-bold.html` — a finished page per direction, built only from these pieces: the quality bar
- `tools/sheet.html` — lets the checker screenshot the page at a real phone width

## Step 1 — the brief (you, ask once)

If the user did not already give these, ask in ONE short Hebrew message (numbered):
1. מה העסק ומה מוכרים?
2. למי זה מיועד?
3. מה הפעולה שהגולש צריך לעשות? (וואטסאפ / טלפון / טופס / קנייה)
4. פרטי קשר: מספר וואטסאפ, ומספר לשיחות טלפון (אם יש — ואם זה אותו מספר, תכתבו)
5. יש צבעים או לוגו? (אם לא — נבחר לבד)
6. משהו שחייב להופיע (מחיר, כתובת, שעות, איסוף/משלוח, המלצות אמיתיות)
7. קישור לאתר שאתם אוהבים (לא חובה)
8. תמונות ולוגו: שימו אותם בתיקייה `images/` (תמונות אמיתיות של העסק, המוצר או שלכם — לא חובה)

Write the answers to `brief.md`. If an answer is missing, write a sensible default and mark it `(הנחה)`.
Check `images/`: list every file there in `brief.md` with one line on what it shows (open each image to see it) — the page may use only these images (the designer picks which; unused ones are not copied). No images → the design works without photos (typographic hero).

## Step 2 — parallel work (one message, two agents at once)

In a SINGLE message launch both agents so they run in parallel:
- `copywriter` → writes `copy.md` (follows `references/copy.md` + `references/structure.md`, picks the blueprint)
- `designer` → writes `design.md` (picks one of the 3 directions, the hero layout, brand overrides)

Do not wait for one before starting the other. Each reads `brief.md` and its references.

## Step 3 — build (you)

Read `copy.md`, `design.md` and `references/design.md`, then write **one file**: `site/index.html`.
- Skeleton: `<html lang="he" dir="rtl">`, `<meta charset="utf-8">`, viewport meta with `viewport-fit=cover`, `<title>` and `<meta name="description">` from the copy, the font `<link>` tags from the top comment of the chosen style file.
- `<style>`: paste `references/styles/<direction>.css` **verbatim** (all of it). Then, only if `design.md` gives brand overrides, add one `:root{…}` block after it. Write no other CSS, except tiny one-off fixes (≤ 10 lines) you can justify.
- Right after `<body>`: paste the `<svg>` block from `references/icons.svg`.
- Markup: only the components from `references/design.md`, in the order of the blueprint in `copy.md`. Top-bar button text = `copy.md` → `## topbar` → `button`. Hero type = the one `design.md` chose. Section backgrounds = `design.md`'s rhythm.
- Text: copy `copy.md` word for word — titles, buttons, micro-copy included; keep the `<em>` in the headline. Do not write new text. Missing text → leave that bit out (and a section with no true content goes away).
- Every call-to-action goes to the real action: `https://wa.me/972XXXXXXXXX?text=` + a URL-encoded Hebrew first message (drop the leading 0 of the number), `tel:+972…`, or an anchor to the form. Phone numbers shown as text sit in `<span dir="ltr">`. `tel:` links (footer line, sticky-bar phone icon) only when the brief gives a number for calls; a WhatsApp-only number gets WhatsApp links only.
- Images: copy to `site/images/` ONLY the files `design.md` actually uses (logo, hero image, the ones placed in `## images`) — not every file the brief lists; images the designer marked `skip` stay out. Use relative paths `images/…`, each with Hebrew `alt` (decorative background: `alt=""`) and the focus class `design.md` gives (`img--top` etc.; never inline `object-position`). Add `width`/`height` attributes when you know them.
- If `copy.md` gives a `sticker` line, add the `sticker` to the hero visual; if the hero has 3+ trust facts (or `## ticker`), add the `ticker` band right after the hero (markup in `references/design.md`).
- Include the sticky mobile bar + its small script from `references/design.md`. No other JavaScript, no frameworks, no build step, nothing that needs an API key.

## Step 4 — check (agent)

Launch `checker` on `site/index.html`. It checks links, facts and mobile rules, takes screenshots (phone 390px sheet, desktop 1280px, and one phone screen scrolled to the end to see the sticky bar over the footer) and looks at them. Fix everything it reports, then run it once more. Stop when it reports `BLOCKERS: none`.

## Step 5 — hand over (you)

Tell the user in Hebrew, short:
- where the file is (`site/index.html`) — open it by double click to see it,
- the screenshots are in `checks/` (phone + desktop),
- to put it online: go to https://app.netlify.com/drop and drag the whole `site` folder there; a link comes back in seconds,
- which design direction was used and why (one line), and that they can ask for another one ("תעשו לי גרסה כהה"),
- one line on what each agent did.

## Rules
- Never invent facts: prices, reviews, numbers, awards, client names, guarantees, deadlines. Missing → leave it out or ask.
- Hebrew in natural spoken style, short sentences; the banned list is in `references/copy.md`.
- One page, one goal: every section leads to the same action.
- The page must look at least as good as the example of its direction (`references/example-<direction>.html`; bold-color → `example-bold.html`). Open it in the browser before you build. If your page looks thinner, emptier or more "template" than it, the build drifted from the components — go back to them.
